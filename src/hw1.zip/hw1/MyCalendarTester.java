/**
 * Example to show the manipulation of Date and Time information through
 * Java 8.0 API.
 * @author: Wesley Zhao
 */


public class MyCalendarTester
{
    public static void main(String [] args) {
        System.out.println("___________________________________________");
        TextMenu tm = new TextMenu();
        //LocalDate test = LocalDate.now();
        //tm.printCalendar(test);
        tm.showMainMenu();
        //TimeTester.testInterval();
    }
}

